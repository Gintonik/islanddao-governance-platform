export { default } from './VotePanel'
