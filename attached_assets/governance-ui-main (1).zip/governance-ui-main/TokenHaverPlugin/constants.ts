import { PublicKey } from '@solana/web3.js'

export const TOKEN_HAVER_PLUGIN = new PublicKey(
  '7gobfUihgoxA14RUnVaseoah89ggCgYAzgz1JoaPAXam'
)
