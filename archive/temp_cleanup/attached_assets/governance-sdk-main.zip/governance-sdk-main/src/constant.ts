import { PublicKey } from "@solana/web3.js";

export const DEFAULT_PROGRAM_ID = new PublicKey("GovER5Lthms3bLBqWub97yVrMmEogzX7xNjdXpPPCVZw");
export const DEFAULT_CHAT_PROGRAM_ID = new PublicKey("gCHAtYKrUUktTVzE4hEnZdLV4LXrdBf6Hh9qMaJALET");