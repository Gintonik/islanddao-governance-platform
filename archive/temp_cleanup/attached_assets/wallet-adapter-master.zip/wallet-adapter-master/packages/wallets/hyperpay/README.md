# `@solana/wallet-adapter-hyperpay`

<!-- @TODO -->

Coming soon.