# `@solana/wallet-adapter-phantom`

<!-- @TODO -->

Coming soon.