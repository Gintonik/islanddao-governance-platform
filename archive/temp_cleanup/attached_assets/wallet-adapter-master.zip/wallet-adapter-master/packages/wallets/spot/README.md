# `@solana/wallet-adapter-spot`

Coming soon.
