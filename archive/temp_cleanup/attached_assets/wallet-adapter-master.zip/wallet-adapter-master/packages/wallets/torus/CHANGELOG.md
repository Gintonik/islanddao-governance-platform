# @solana/wallet-adapter-torus

## 0.11.31

### Patch Changes

- db923f1: Use Node 20+ rather than 22
- Updated dependencies [db923f1]
    - @solana/wallet-adapter-base@0.9.26

## 0.11.30

### Patch Changes

- 27e408d: Update dependencies
- Updated dependencies [27e408d]
    - @solana/wallet-adapter-base@0.9.25

## 0.11.29

### Patch Changes

- c96cae47: The base version of Node has been raised to v20
- Updated dependencies [c96cae47]
    - @solana/wallet-adapter-base@0.9.24

## 0.11.28

### Patch Changes

- Updated dependencies [a3d35a1]
    - @solana/wallet-adapter-base@0.9.23

## 0.11.27

### Patch Changes

- 8a8fdc72: Update dependencies
- Updated dependencies [8a8fdc72]
    - @solana/wallet-adapter-base@0.9.22

## 0.11.26

### Patch Changes

- Updated dependencies [f99c2154]
    - @solana/wallet-adapter-base@0.9.21

## 0.11.25

### Patch Changes

- Updated dependencies [912cc0e]
    - @solana/wallet-adapter-base@0.9.20

## 0.11.24

### Patch Changes

- Updated dependencies [353f2a5]
    - @solana/wallet-adapter-base@0.9.19
