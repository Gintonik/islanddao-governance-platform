# `@solana/wallet-adapter-unsafe-burner`

This is the default wallet adapter used in the starter packs. This adapter implements the Wallet Adapter interface, but uses an unsafe local keypair to sign messages.

See https://github.com/anza-xyz/wallet-adapter#usage for an example of how to configure your app for compatibility with a list of wallets of your choosing.
