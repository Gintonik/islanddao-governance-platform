# `@solana/wallet-adapter-saifu`

Wallet adapter for integrating https://saifuwallet.com/
