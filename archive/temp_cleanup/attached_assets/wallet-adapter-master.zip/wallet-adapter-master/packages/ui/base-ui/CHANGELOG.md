# @solana/wallet-adapter-base-ui

## 0.1.5

### Patch Changes

- db923f1: Use Node 20+ rather than 22
- Updated dependencies [db923f1]
    - @solana/wallet-adapter-react@0.15.38

## 0.1.4

### Patch Changes

- 27e408d: Update dependencies
- Updated dependencies [27e408d]
    - @solana/wallet-adapter-react@0.15.37

## 0.1.3

### Patch Changes

- c96cae47: The base version of Node has been raised to v20
- Updated dependencies [e25e7971]
- Updated dependencies [c96cae47]
    - @solana/wallet-adapter-react@0.15.36

## 0.1.2

### Patch Changes

- Updated dependencies [bdc0eff]
    - @solana/wallet-adapter-react@0.15.35

## 0.1.1

### Patch Changes

- Updated dependencies [a3d35a1]
    - @solana/wallet-adapter-react@0.15.34

## 0.1.0

### Minor Changes

- 7b06737: Add base-ui package with wallet button hooks

### Patch Changes

- Updated dependencies [7b06737]
- Updated dependencies [ba57f75]
- Updated dependencies [7c6f2e1]
    - @solana/wallet-adapter-react@0.15.33
