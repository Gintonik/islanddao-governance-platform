# `@solana/wallet-adapter-base-ui`

<!-- @TODO -->

Coming soon.
