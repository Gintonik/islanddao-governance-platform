# @solana-wallets/react-next

## 0.1.14

### Patch Changes

- Updated dependencies
  - @solana-wallets/unified@0.3.14

## 0.1.13

### Patch Changes

- Updated dependencies
  - @solana-wallets/unified@0.3.8
  - @solana-wallets/react-2.0@0.5.0

## 0.1.12

### Patch Changes

- Updated dependencies
  - @solana-wallets/unified@0.3.7

## 0.1.11

### Patch Changes

- Updated dependencies
  - @solana-wallets/unified@0.3.6

## 0.1.10

### Patch Changes

- Updated dependencies
  - @solana-wallets/unified@0.3.5

## 0.1.9

### Patch Changes

- Updated dependencies
  - @solana-wallets/unified@0.3.4

## 0.1.8

### Patch Changes

- Updated dependencies
  - @solana-wallets/unified@0.3.3

## 0.1.7

### Patch Changes

- Updated dependencies
  - @solana-wallets/unified@0.3.2

## 0.1.6

### Patch Changes

- Updated dependencies
  - @solana-wallets/unified@0.3.1

## 0.1.5

### Patch Changes

- Updated dependencies
  - @solana-wallets/react-2.0@0.5.0
  - @solana-wallets/unified@0.3.0

## 0.1.4

### Patch Changes

- Updated dependencies
  - @solana-wallets/react-2.0@0.4.0
  - @solana-wallets/unified@0.2.0
