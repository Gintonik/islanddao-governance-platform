/// <reference types="@solidjs/start/env" />
