import "@/styles/tailwind.css"
import "@solana-wallets/unified/index.css"
