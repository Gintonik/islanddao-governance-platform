# @solana-wallets/react-2.0

## 0.5.0

### Minor Changes

- export all core packages

## 0.4.0

### Minor Changes

- wallet-standard working
