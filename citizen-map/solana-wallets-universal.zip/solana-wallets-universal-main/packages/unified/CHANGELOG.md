# @solana-wallets/unified

## 0.3.14

### Patch Changes

- test: div within button

## 0.3.8

### Patch Changes

- query for available wallets on unified mount

## 0.3.7

### Patch Changes

- unified logging

## 0.3.6

### Patch Changes

- types

## 0.3.5

### Patch Changes

- update solid-element

## 0.3.4

### Patch Changes

- remove preflight

## 0.3.3

### Patch Changes

- tailwind fix

## 0.3.2

### Patch Changes

- export build

## 0.3.1

### Patch Changes

- no build

## 0.3.0

### Minor Changes

- export all core packages

## 0.2.0

### Minor Changes

- wallet-standard working
