# @solana-wallets/solid-2.0

## 0.11.4

### Patch Changes

- @solana-wallets/core-2.0@0.8.7

## 0.11.3

### Patch Changes

- @solana-wallets/core-2.0@0.8.6

## 0.11.2

### Patch Changes

- Updated dependencies
  - @solana-wallets/core-2.0@0.8.5

## 0.11.1

### Patch Changes

- add import
- Updated dependencies
  - @solana-wallets/core-2.0@0.8.4

## 0.11.0

### Minor Changes

- update vinxi

## 0.10.4

### Patch Changes

- only import solana-mobile-adapter in 1.0 packages
  - @solana-wallets/core-2.0@0.8.3

## 0.10.3

### Patch Changes

- test dynamic types
  - @solana-wallets/core-2.0@0.8.2

## 0.10.2

### Patch Changes

- add imported as deps
- Updated dependencies
  - @solana-wallets/core-2.0@0.8.1

## 0.10.1

### Patch Changes

- no build

## 0.10.0

### Minor Changes

- export all core packages

## 0.9.0

### Minor Changes

- export all typers

## 0.8.0

### Minor Changes

- add types

## 0.7.0

### Minor Changes

- wallet-standard working
