# @solana-wallets/core-1.0

## 0.8.5

### Patch Changes

- Updated dependencies
  - @solana-wallets/core@0.8.4

## 0.8.4

### Patch Changes

- Updated dependencies
  - @solana-wallets/core@0.8.3

## 0.8.3

### Patch Changes

- only import solana-mobile-adapter in 1.0 packages
- Updated dependencies
  - @solana-wallets/core@0.8.2

## 0.8.2

### Patch Changes

- Updated dependencies
  - @solana-wallets/core@0.8.1

## 0.8.1

### Patch Changes

- add imported as deps

## 0.8.0

### Minor Changes

- export all core packages

## 0.7.0

### Minor Changes

- wallet-standard working
