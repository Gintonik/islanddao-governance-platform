# Core

Internal core package containing wallet state management (via nanostores) + wallet-standard compatible wallet fetching

## How to use it

This package is NOT meant for direct use.

Users should install the [core-1.0](../core-1.0) or [core-2.0](../core-2.0) packages based on the `@solana/web3.js` version being used in your project

## Changelog

See [CHANGELOG.md](./CHANGELOG.md).
