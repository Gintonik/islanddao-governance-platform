# @solana-wallets/core

## 0.8.4

### Patch Changes

- query for available wallets on unified mount

## 0.8.3

### Patch Changes

- log values

## 0.8.2

### Patch Changes

- only import solana-mobile-adapter in 1.0 packages

## 0.8.1

### Patch Changes

- test dynamic types

## 0.8.0

### Minor Changes

- export all core packages

## 0.7.0

### Minor Changes

- wallet-standard working
